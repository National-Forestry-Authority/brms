# Ludwig

This module provides a manual alternative to Composer for Drupal 8+ users.

## Ludwig documentation

https://www.drupal.org/docs/contributed-modules/ludwig

## Name origin

Ludwig van Beethoven was a **deaf composer**.
